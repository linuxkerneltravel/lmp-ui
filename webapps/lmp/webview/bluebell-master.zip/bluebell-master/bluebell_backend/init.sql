-- create the databases
CREATE DATABASE IF NOT EXISTS bluebell;