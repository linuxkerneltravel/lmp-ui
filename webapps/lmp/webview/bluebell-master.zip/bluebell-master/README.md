# bluebell
bluebell


## 清单


1. zap日志库
2. Viper配置管理
3. 整合脚手架


Go语言操作MySQL
Go语言操作Redis
Go语言操作Kafka
ES搭建搜索

